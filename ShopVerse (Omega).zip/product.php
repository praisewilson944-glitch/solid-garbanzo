<?php
// Set response type
header('Content-Type: application/json');

// Sample product data
$products = [
  [
    "shopName" => "Tech Haven",
    "title" => "PM18 Wireless Earbuds",
    "price" => 7500,
    "location" => "Lagos",
    "images" => [
      "/IMG-20250918-WA0003.jpg",
      "/IMG-20250918-WA0006.jpg",
      "/IMG-20250922-WA0014.jpg"
    ]
  ],
  [
    "shopName" => "Style Hub",
    "title" => "Vintage Sunglasses",
    "price" => 3200,
    "location" => "Abuja",
    "images" => [
      "/IMG-20250922-WA0016.jpg",
      "/IMG-20250922-WA0019.jpg"
    ]
  ],
  [
    "shopName" => "Gadget Zone",
    "title" => "Smartwatch X9",
    "price" => 12500,
    "location" => "Port Harcourt",
    "images" => [
      "/IMG-20250922-WA0024.jpg",
      "/IMG-20250908-WA0021.jpg"
    ]
  ]
];

// Output as JSON
echo json_encode($products);
?>
